![GlycoGenius banner](./banner.png "GlycoGenius")

# GlycoGenius - The Ultimate Glycomics Data Analysis Tool

GlycoGenius is an open-source program offering an automated workflow for glycomics data analysis, featuring an intuitive graphical interface. 

Current software tools are effective in certain aspects of glycomics data analysis but all require significant effort to reach satisfactory qualitative results, often requiring months of manual data curation, revision and integration.

With that in mind, GlycoGenius is tailored to reduce manual workload. It allows for data visualization (using the GUI) and automatically constructs search spaces, identifies, scores, and quantifies glycans, filters results, and annotates fragment spectra of N- and O-glycans, glycosaminoglycans and more.

## Installation

There are two ways to install it:
1. Download the latest version of the Graphical User Interface from Releases page on https://github.com/LoponteHF/GlycoGenius_GUI, unzip it and run the executable file (Windows only, for other OS, you can install the GUI from PyPI);
2. Install from PyPI:
	1. Install Python from [python.org](https://www.python.org/) or from your OS package distributor;
	2. Type "pip install glycogenius" or "pip3 install glycogenius" on a terminal.
	
Older versions of MacOS might not install GlycoGenius properly on Python versions 3.14 or later, so install an earlier, compatible Python version, such as 3.13.
	
## Usage

1. Export your MS data to an MzXML or MzML file;
2. Type 'glycogenius' in the terminal;
~~~
		glycogenius
~~~
3. Follow instructions:
   - You can analyze directly on the CLI;
   - You can export a parameters file for advanced executions;
4. If you exported the parameters file, pipeline it to glycogenius after setting it up.
   - eg. in terminal type:
~~~
        cat .\glycogenius_parameters.ini | glycogenius
~~~

For detailed information on the different settings, access the [Instructions Manual](https://github.com/LoponteHF/GlycoGenius_GUI/blob/main/GlycoGenius_Instructions_Manual.pdf). It will be updated periodically, but less often than the program itself, so some features may be missing in it.

## Features Development and Suggestions

If you want to suggest a new feature or be aware of what's intended down the road for GlycoGenius, feel free to check our [Trello dashboard](https://trello.com/b/qJU80MXM/glycogenius-dev-dashboard).

## Citation

> GlycoGenius: the ultimate high-throughput glycan composition identification tool
> Hector F. Loponte, Jing Zheng, Yajie Ding, Isadora A. Oliveira, Kristoffer Basse, Adriane R. Todeschini, Peter L. Horvatovich, Guinevere S.M. Lageveen-Kammeijer
> bioRxiv 2025.03.10.642485; doi: https://doi.org/10.1101/2025.03.10.642485 

## Credits

Pyteomics:

> Goloborodko, A.A.; Levitsky, L.I.; Ivanov, M.V.; and Gorshkov, M.V. (2013) “Pyteomics - a Python Framework for Exploratory Data Analysis and Rapid Software Prototyping in Proteomics”, Journal of The American Society for Mass Spectrometry, 24(2), 301–304. DOI: 10.1007/s13361-012-0516-6

> Levitsky, L.I.; Klein, J.; Ivanov, M.V.; and Gorshkov, M.V. (2018) “Pyteomics 4.0: five years of development of a Python proteomics framework”, Journal of Proteome Research. DOI: 10.1021/acs.jproteome.8b00717

Dill for Python:

> M.M. McKerns, L. Strand, T. Sullivan, A. Fang, M.A.G. Aivazis, "Building a framework for predictive science", Proceedings of the 10th Python in Science Conference, 2011; http://arxiv.org/pdf/1202.1056

> Michael McKerns and Michael Aivazis, "pathos: a framework for heterogeneous computing", 2010- ;	https://uqfoundation.github.io/project/pathos

Numpy:

> Harris, C.R., Millman, K.J., van der Walt, S.J. et al. Array programming with NumPy. Nature 585, 357–362 (2020). DOI: 10.1038/s41586-020-2649-2.

SciPy:

> Pauli Virtanen, Ralf Gommers, Travis E. Oliphant, Matt Haberland, Tyler Reddy, David Cournapeau, Evgeni Burovski, Pearu Peterson, Warren Weckesser, Jonathan Bright, Stéfan J. van der Walt, Matthew Brett, Joshua Wilson, K. Jarrod Millman, Nikolay Mayorov, Andrew R. J. Nelson, Eric Jones, Robert Kern, Eric Larson, CJ Carey, İlhan Polat, Yu Feng, Eric W. Moore, Jake VanderPlas, Denis Laxalde, Josef Perktold, Robert Cimrman, Ian Henriksen, E.A. Quintero, Charles R Harris, Anne M. Archibald, Antônio H. Ribeiro, Fabian Pedregosa, Paul van Mulbregt, and SciPy 1.0 Contributors. (2020) SciPy 1.0: Fundamental Algorithms for Scientific Computing in Python. Nature Methods, 17(3), 261-272.

Whittaker-Eilers smoothing implementation:

> P. H. C. Eilers, "A perfect smoother", Anal. Chem. 2003, 75, 3631-3636

> J. Midelet, A. H. El-Sagheer, T. Brown, A. G. Kanaras, A. Débarre, M. H. V. Werts, "Spectroscopic and Hydrodynamic Characterisation of DNA-Linked Gold Nanoparticle Dimers in Solution using Two-Photon Photoluminescence", ChemPhysChem 2018, 19, 827.

Pandas:

> The pandas development team, Pandas, Zenoddo, Feb 2020, DOI:10.5281/zenodo.3509134

Logo/Banner Image:

> Based on an image generated by Bing Copilot (powered by DALL-E 3)

## License

This project is licensed under [GNU GPLv3 or later](https://spdx.org/licenses/GPL-3.0-or-later.html)